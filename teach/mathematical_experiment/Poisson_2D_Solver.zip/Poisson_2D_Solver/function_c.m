function r=function_c(x,y)
%Xiaoming He, 07/05/2009.

r=1;