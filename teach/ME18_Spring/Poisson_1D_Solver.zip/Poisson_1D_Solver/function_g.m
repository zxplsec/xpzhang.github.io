function result=function_g(x)
left=0;
right=1;

if x==left
    result=0;
elseif x==right
    result=cos(1);
end

end