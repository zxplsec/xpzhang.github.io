function result=function_c(x)

result=exp(x);