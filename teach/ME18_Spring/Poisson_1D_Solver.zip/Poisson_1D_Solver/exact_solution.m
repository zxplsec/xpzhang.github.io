function result=exact_solution(x)

result=x.*cos(x);